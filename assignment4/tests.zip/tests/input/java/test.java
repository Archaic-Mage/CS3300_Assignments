class test {
    public static void main(String[] a){
        System.out.println(new lol().wut());
        }
}

class lol {
    boolean a;
    boolean b;
    boolean c;
    int x;
    public int wut()
    {
        int[] arr;
        arr = new int[10];
        arr[0] = 69;
        return this.huh(arr);
    }

    public int huh(int[] arr)
    {
        return arr[0];
    }
}