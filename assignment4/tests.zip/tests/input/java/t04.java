class t04 {
    public static void main(String[] args) {
        System.out.println(new t041().run());
    }
}

class t041 {
    public int run() {
        return 0;
    }

    public int set() {
        return this.run();
    }
}