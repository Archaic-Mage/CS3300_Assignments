class lol {
    public static void main(String[] args) {
        System.out.println(1);
    }
}
