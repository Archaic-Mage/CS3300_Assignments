class MyCustomTest{
    public static void main(String[] a){
        System.out.println(new Fac().ComputeFac((10+0)));
    }
}

class Fac {
    public int ComputeFac(int num){
        int num_aux;
        num_aux = 0-10;
        System.out.println(num_aux);
        return num_aux;
    }
}
