class prid 
{
	public static void main (String [] a)
	{
		System.out.println(1);
	}
}

class Min
{
	public int min(int x, int y)
	{
		int a;
		lol b;
		lol huh;
		
        huh = new lol();
		x  = (huh).print1();
		a = new huh().print();

		return a;
	}
}

class lol
{
	public int print1()
	{
        System.out.println(2);
		return 2;
	}
}

class huh
{
	public int print()
	{
        System.out.println(1);
		return 1;
	}
}